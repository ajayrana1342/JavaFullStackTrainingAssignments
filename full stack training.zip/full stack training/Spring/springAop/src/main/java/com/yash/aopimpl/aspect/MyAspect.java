package com.yash.aopimpl.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Aspect
@EnableAspectJAutoProxy
public class MyAspect {

	@Before("execution(* com.yash.aopimpl.services.PaymentServiceImpl.makePayment())")
	public void printBefore() {
		System.out.println("Payment Initilaized");
	}

	@After("execution(* com.yash.aopimpl.services.PaymentServiceImpl.makePayment())")
	public void printAfter() {
		System.out.println("Payment Completed");
	}
	
	@Before("myPointCuts()")
	public void printB() {
		System.out.println("Payment initialise");
	}	
	
	@After("myPointCuts()")
	public void printA() {
		System.out.println("Payment Done");
	}	
	
	@Pointcut("execution(public * makePayment*())")
	public void myPointCuts() {}
}