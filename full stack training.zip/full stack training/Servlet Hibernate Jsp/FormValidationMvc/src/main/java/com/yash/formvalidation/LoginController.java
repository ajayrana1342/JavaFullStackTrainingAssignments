package com.yash.formvalidation;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {
	@RequestMapping("/login")  
    public String display(Model m)  
    {  
        m.addAttribute("log", new Login());  
        return "viewpage";  
    }  
    @RequestMapping("/loginagain")  
    public String submitForm( @Valid @ModelAttribute("log") Login l, BindingResult br)  
    {  
        if(br.hasErrors())  
        {  
            return "viewpage";  
        }  
        else  
        {  
        return "final";  
        }  
    }  
}
