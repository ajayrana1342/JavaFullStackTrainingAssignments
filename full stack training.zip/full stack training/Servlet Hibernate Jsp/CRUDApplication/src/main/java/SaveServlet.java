
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SaveServlet
 */
@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();
        out.print("<style>");
        out.print("nav a{");
        out.print("padding:10px;");
        out.print("text-decoration:none;");
	    out.print("}");
	    out.print("nav{");
       out.print("text-align:center");
       out.print("}");
        out.print("</style>");
        out.print("<nav>");
        out.print("<a href='index.html'>Home</a>");
        out.print("<a href='SaveServlet'>Save details</a>");
        out.print("<a href='ViewServlet'>View Details</a>");
        out.print("</nav>");
        String id=request.getParameter("student_id");
        String username=request.getParameter("username");
        String gender=request.getParameter("gender");
        String email=request.getParameter("email");
        String department=request.getParameter("department");
        String semester=request.getParameter("semester");
        String password=request.getParameter("password");
        Details d=new Details();
        d.setStudent_id(id);
        d.setUsername(username);
        d.setGender(gender);
        d.setEmail(email);
        d.setDepartment(department);
        d.setSemester(semester);
        d.setPassword(password);
        int status=DetailsCon.save(d);
        if(status>0)
        	out.print("<p>Record Saved Successfully!!!</p>");
        else
        	out.print("<p>Unable to Save the record!</p>");
        out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
