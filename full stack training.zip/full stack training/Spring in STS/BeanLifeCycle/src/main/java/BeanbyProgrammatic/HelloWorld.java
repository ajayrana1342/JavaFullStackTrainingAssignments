package BeanbyProgrammatic;

import org.springframework
.beans.factory.DisposableBean;

import org.springframework
.beans.factory.InitializingBean;

//HelloWorld class which implements the
//interfaces
public class HelloWorld implements InitializingBean,DisposableBean {

	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("in destroy");
		
	}

	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("in properties");
		
	}
	
	

}
