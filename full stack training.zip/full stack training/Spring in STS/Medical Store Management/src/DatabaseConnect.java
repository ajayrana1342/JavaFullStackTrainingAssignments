import MedicalStore.Medicine;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Statement;

public class DatabaseConnect 

{
	public Connection start() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/medical";
		String user="root";
		String pass="root";
		Connection con=DriverManager.getConnection(url,user,pass);
		return con;
	}
	
	public void close(Connection c) throws Exception{
		c.close();
	}
	public int insert(Medicine m) throws Exception
	{
		 String name=m.getName();
		 int qnt=m.getQnt();
		 String exp=m.getExp();
		 float cp=m.getCp();
		 float sp=m.getSp();
		 Connection con= start();
		 PreparedStatement st=con.prepareStatement("insert into medicine(name,quantity,expirydate,costprice,sellprice) values(?,?,?,?,?)");
		 st.setString(1, name);
		 st.setInt(2,qnt);
		 st.setString(3, exp);
		 st.setFloat(4, cp);
		 st.setFloat(5, sp);
		 int i= st.executeUpdate();
		 close(con);
		 if(i>0) {
			 return 1;
		 };
		 return 0;
	}
	public int update(String name,int Qnt) throws Exception
	{
		Connection con=start();
		PreparedStatement st=con.prepareStatement("update medicine set quantity=? where name=?");
		st.setInt(1, Qnt);
		st.setString(2,name);
		int i=st.executeUpdate();
		close(con);
		if(i>0) 
		{
			return 1;
			
		}
		return 0;
		
	}
    public int remove(String name) throws Exception
    {
    	Connection con=start();
		PreparedStatement st=con.prepareStatement("delete from medicine  where name=?");
		st.setString(1, name);
		int i=st.executeUpdate();
		close(con);
		if(i>0) 
		{
			return 1;
			
		}
		return 0;
    	
    }
    public void display() throws Exception
    {
    	Connection con=start();
    	String q="select* from medicine";
	    Statement st=con.createStatement();
	    ResultSet set=st.executeQuery(q);
	    System.out.println("name   quantity    expirydate    costprice   sellprice");
	    System.out.println("             ");
	    while(set.next()) 
	    {
	    	String name=set.getString("name");
	    	int quantity=set.getInt("quantity");
	    	String expirydate=set.getString("expirydate");
	    	float costprice=set.getFloat("costprice");
	    	float sellprice=set.getFloat("sellprice");
	    	
			
			System.out.println(name+"   "+quantity+"   "+expirydate+"   "+costprice+"   "+sellprice);
			
	    }
	    close(con);
   
	 }
    public void display(String name) throws Exception
    {
    	Connection con=start();
	   PreparedStatement st= con.prepareStatement("select * from medicine where name=?");
	   st.setString(1,name);
	   
	  ResultSet set=st.executeQuery();
	    while(set.next()) 
	    {
	    	String name1=set.getString("name");
	    	int quantity=set.getInt("quantity");
	    	String expirydate=set.getString("expirydate");
	    	float costprice=set.getFloat("costprice");
	    	float sellprice=set.getFloat("sellprice");
	    	
			System.out.println("name   quantity    expirydate    costprice   sellprice");
			System.out.println(name1+"   "+quantity+"   "+expirydate+"   "+costprice+"   "+sellprice);
			
	    }
	    close(con);
    }
    public int sell(String name,int quantity) throws Exception
    
    {

    	int q1=0;
    	float cp1=0,sp1=0;
    	float p1=0;
    	Connection con=start();
    	PreparedStatement st= con.prepareStatement("select* from medicine where name=?");
    	st.setString(1, name);
  	    ResultSet set=st.executeQuery();
  	    while(set.next()) 
  	    {
  	      q1=set.getInt("quantity");
  	     cp1=set.getFloat("costprice");
  	     sp1=set.getFloat("sellprice");
  	     
  	    }
  	    
  	    
  	    int q2=q1-quantity;
		if(q2<=0){
			close(con);
			return 0;}
		
		else{
			PreparedStatement st1= con.prepareStatement("select* from profit ");
	  	    ResultSet set1=st1.executeQuery();
	  	    while(set1.next()) 
	  	    {
	  	      p1=set1.getFloat("profit");
	  	     
	  	    }
	  	    float pr=p1+((sp1-cp1)*quantity);
	  	    update(name,q2);
	  	  PreparedStatement st2= con.prepareStatement("update profit set profit=? ");
	  	  st2.setFloat(1, pr);
	  	  st2.executeUpdate();
	  	    
		}
		close(con);
		return 1;	
    	
	    
    	

    }
    
    public float profit() throws Exception
    {
    	Connection con=start();
    	String q="select *from profit";
	    Statement st=con.createStatement();
	    ResultSet set=st.executeQuery(q);
        float pr=0;
        while(set.next()) 
        {
        	pr=set.getFloat("profit");
        }
        return pr;
	    
    	
    }
}
