package com.yash.MessageSource;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;

public class Employee {

	@Autowired
	private MessageSource messagesource;
	// @Autowired
	// @Qualifier("address1")
	private Address address;

	public Address getAddress() {
		return address;
	}

//@Autowired
	public void setAddress(Address address) {
		this.address = address;
		System.out.println("setting the address");
	}

	@Autowired

	public Employee(Address address) {
		super();
		this.address = address;
		System.out.println("Inside the address");
	}

	@Override
	public String toString() {
		return "Employee [address=" + address + "]";
	}

	public Employee() {
		super();
// TODO Auto-generated constructor stub
	}
	
	public MessageSource getMessagesource() {
		return messagesource;
	}

	public void setMessagesource(MessageSource messagesource) {
		this.messagesource = messagesource;
	}
	public void show() 
	{
		System.out.println(this.messagesource.getMessage("greeting",null,"Default Greeting",null));
		System.out.println(this.messagesource.getMessage("address1",new Object[] {address.getStreet(),address.getCity()},"Default Address",null));
		
	}

}
