package Bybean;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import Bybean.Employee;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println("Welcome to Spring First Application");
		 Resource resource=new ClassPathResource("applicationcontext.xml");
		 BeanFactory factory=new XmlBeanFactory(resource);
         //ApplicationContext context=new  ClassPathXmlApplicationContext("applicationcontext.xml");
         Employee e=(Employee) factory.getBean("employee");
         System.out.println(e);


	}

}
