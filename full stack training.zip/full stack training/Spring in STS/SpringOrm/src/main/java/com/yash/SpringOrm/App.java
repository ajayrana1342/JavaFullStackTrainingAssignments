package com.yash.SpringOrm;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.SpringOrm.dao.StudentDao;
import com.yash.SpringOrm.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDao studao = context.getBean("studentDao", StudentDao.class);
		Student stu = new Student(5, "Abhisekh");
		int msg = studao.insert(stu);
		//studao.deleteDetails(2);
		//System.out.println(msg + "insertion done");
		//studao.updateDetails(stu);
	    List<Student> s=studao.getAllStudents();
	    
	    for(Student e:s) 
	    {
	    	System.out.println(e);
	    }
	}
}
