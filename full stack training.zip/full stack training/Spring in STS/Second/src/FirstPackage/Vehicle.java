package FirstPackage;

public class Vehicle
{  
  public void show(){
  System.out.println("I am in vehicle class");}
 }