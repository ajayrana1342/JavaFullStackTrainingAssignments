
public class ThreadDemoRunnable implements Runnable
{
	public void run() 
	{
		System.out.println("In run");
	}
    public static void main(String args[])
    {
    	ThreadDemoRunnable t=new ThreadDemoRunnable();
    	Thread t1=new Thread(t);
    	t1.start();
    	
    }
}
