class BookTicket1
{
	int totalseats=12;
   synchronized void bookSeat(int seats) 
	{   
   
		if(totalseats>=seats) 
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats "+totalseats);
		}
		else 
		{
			System.out.println("seats are not available "+totalseats );
		}
	}
 	
}

public class TicketWithSync extends Thread
{
	static BookTicket1 b;
	int seats;
	public void run() 
	{
		b.bookSeat(seats);
	}
	public static void main(String[] args) 
	{
		b=new BookTicket1();
		TicketWithSync p1=new TicketWithSync();
		p1.seats=8;
		p1.start();
		TicketWithSync p2=new TicketWithSync();
		p2.seats=10;
		p2.start();
		
		
	}

}
