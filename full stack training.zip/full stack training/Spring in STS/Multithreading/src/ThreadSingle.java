
class Singlethread extends Thread
{
	public void run() 
	{
		System.out.println("Single thread");
	}
}
public class ThreadSingle
{
    public static void main(String args[])
    { 
    	Singlethread  t=new Singlethread();
    	t.start();

}}
