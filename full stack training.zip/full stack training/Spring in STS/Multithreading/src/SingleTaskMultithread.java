

class Singlethread1 extends Thread
{
	public void run() 
	{
		System.out.println("Single thread");
	}
}
public class SingleTaskMultithread
{
    public static void main(String args[])
    { 
    	Singlethread1  t=new Singlethread1();
    	t.start();
    	Singlethread1  t1=new Singlethread1();
        t1.start();
}}
