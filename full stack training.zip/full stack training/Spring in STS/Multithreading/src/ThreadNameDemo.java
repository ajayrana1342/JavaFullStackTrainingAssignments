
public class ThreadNameDemo extends Thread
{
	public void run() 
	{
		Thread.currentThread().setName("run");
		System.out.println(Thread.currentThread().getName());
	}
	public static void main(String args[] ) 
	{
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().isAlive());
		ThreadNameDemo t=new ThreadNameDemo();
		System.out.println(t.isAlive());
		t.setName("t1 thread");
		t.start();
		System.out.println(t.isAlive());
	}

}
