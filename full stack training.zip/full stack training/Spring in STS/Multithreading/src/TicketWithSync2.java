class BookTicket2
{
	int totalseats=12;
    void bookSeat(int seats) 
	{   
      synchronized(this) 
      {
		if(totalseats>=seats) 
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats "+totalseats);
		}
		else 
		{
			System.out.println("seats are not available "+totalseats );
		}
      }
	}
 	
}

public class TicketWithSync2 extends Thread
{
	static BookTicket2 b;
	int seats;
	public void run() 
	{
		b.bookSeat(seats);
	}
	public static void main(String[] args) 
	{
		b=new BookTicket2();
		TicketWithSync2 p1=new TicketWithSync2();
		p1.seats=8;
		p1.start();
		TicketWithSync2 p2=new TicketWithSync2();
		p2.seats=10;
		p2.start();
		
		
	}

}
