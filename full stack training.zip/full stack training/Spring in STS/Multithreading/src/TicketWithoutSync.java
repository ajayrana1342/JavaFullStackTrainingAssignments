class BookTicket
{
	int totalseats=12;
	void bookSeat(int seats) 
	{
		if(totalseats>=seats) 
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats "+totalseats);
		}
		else 
		{
			System.out.println("seats are not available "+totalseats );
		}
	}
 	
}

public class TicketWithoutSync extends Thread
{
	static BookTicket b;
	int seats;
	public void run() 
	{
		b.bookSeat(seats);
	}
	public static void main(String[] args) 
	{
		b=new BookTicket();
		TicketWithoutSync p1=new TicketWithoutSync();
		p1.seats=8;
		p1.start();
		TicketWithoutSync p2=new TicketWithoutSync();
		p2.seats=10;
		p2.start();
		
		
	}

}
