
class Firstthread extends Thread
{
	public void run() 
	{
		System.out.println("Single thread");
	}
}
class Secondthread extends Thread
{
	public void run() 
	{
		System.out.println("second thread");
	}
}
class Thirdthread extends Thread
{
	public void run() 
	{
		System.out.println("third thread");
	}
}
public class MultitaskMultithread
{
    public static void main(String args[])
    { 
    	Singlethread  t=new Singlethread();
    	t.start();
    	Secondthread t1=new Secondthread();
    	t1.start();
    	Thirdthread t2=new Thirdthread();
    	t2.start();
}}
