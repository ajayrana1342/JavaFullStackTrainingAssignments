
public class ThreadDaemonDemo extends Thread
{
	public void run() 
	{
		if(Thread.currentThread().isDaemon()) 
		{
			System.out.println("I am in daemon thread");
		}
		else 
		{
			System.out.println("I am in non-daemon thread");
		}
		
	}
	
	public static void main(String args[]) 
	{
		System.out.println("Main thread");
		//Thread.currentThread().setDaemon(true); we cannot create main thread as daemon thread
		ThreadDaemonDemo t=new ThreadDaemonDemo();
		t.setDaemon(true);
		t.start();
		ThreadDaemonDemo t1=new ThreadDaemonDemo();
		t1.setDaemon(false);
		t1.start();

		
	}

}
