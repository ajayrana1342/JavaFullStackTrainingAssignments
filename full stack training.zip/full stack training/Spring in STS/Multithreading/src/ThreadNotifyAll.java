class Revenue0 extends Thread
{
	public void run() 
	{
		synchronized(this) 
		{
			System.out.println("Thread-1");
			try 
			{
				this.wait();
			}
			catch(Exception e) 
			{
				e.printStackTrace();
			}
		}
	}
}
class Revenue1 extends Thread
{    Revenue0 r;
     Revenue1(Revenue0 r){this.r=r;}
	public void run() 
	{
		synchronized(this.r) 
		{
			System.out.println("Thread-2");
			try 
			{
				this.r.wait();
			}
			catch(Exception e) 
			{
				e.printStackTrace();
			}
		}

	}
}
class Revenue2 extends Thread
{    Revenue0 r;
    Revenue2(Revenue0 r)
    {this.r=r;}
	public void run() 
	{
		synchronized(this.r) 
		{
			System.out.println("Thread-3");
			try 
			{
				this.r.notifyAll();}
			catch(Exception e) 
			{
				e.printStackTrace();
			}
		}

	}
}
public class ThreadNotifyAll 
{
	public static void main(String[] args) throws Exception
	{
		Revenue0 r=new Revenue0();
		Revenue1 r1=new Revenue1(r);
		Revenue2 r2=new Revenue2(r);
		Thread t1=new Thread(r);
		Thread t2=new Thread(r1);
		Thread t3=new Thread(r2);
		t1.start();
		t2.start();
		t3.start();
		
		
		
	}

}
