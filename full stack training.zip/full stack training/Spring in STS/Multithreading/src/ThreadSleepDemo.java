
public class ThreadSleepDemo extends Thread
{
	public void run() 
	{
		for(int i=1;i<3;i++)
		{		
			try 
		
		{
			Thread.sleep(50);
			System.out.println(Thread.currentThread().getName());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println(i);
	}
	}
	public static void main(String argsp[]) 
	{
		ThreadSleepDemo t=new ThreadSleepDemo();
		t.setName("Yash");
		t.setPriority(MAX_PRIORITY);
		t.start();
		ThreadSleepDemo t1=new ThreadSleepDemo();
		t1.setName("AJAY");
		t1.setPriority(1);
		t1.start();
		
	}
   
}
