package Stereo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("Stereo/applicationcontext.xml");
		Employee e = context.getBean("ob", Employee.class);
		System.out.println(e);
		System.out.println(e.hashCode());  
		Employee e1 = context.getBean("ob", Employee.class);
		Employee e2 = context.getBean("ob", Employee.class);
		System.out.println(e1.hashCode());
		System.out.println(e2.hashCode());
	}

}