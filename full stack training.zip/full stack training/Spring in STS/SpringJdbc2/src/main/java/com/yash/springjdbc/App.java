package com.yash.springjdbc;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.EmployeeDao;
import com.yash.springjdbc.entities.Employee;


/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		EmployeeDao stdao = context.getBean("EmployeeDao", EmployeeDao.class);

		/*Employee e = new Employee();
		e.setEmpname("Tanish");
		e.setEmailid("tanish@gmail.com");
		e.setDate("2022/05/31");
		e.setContactno(4874784);
		e.setSalary(60000);*/
		
		
		//int r = stdao.updatedetails(e);
		//int r=stdao.insert(e);
	
		//int r=stdao.deletedetails("Tanish");
		


		//System.out.println(r + "employee added Successfully ");
		
	    List<Employee> list=stdao.getAllEmployeesRowMapper();  
	          
	    for(Employee e:list)  
	        System.out.println(e);  
	}
	
	                     	 
}