package com.yash.springjdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.yash.springjdbc.entities.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbctemp;
	
	
	public int insert(Employee emp) {

		String q = "insert into employee(empname,emailid,dob,contactno,salary) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getEmpname(), emp.getEmailid(),emp.getDate(),emp.getContactno(),emp.getSalary());
		return msg;
	}


	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}


	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int updatedetails(Employee emp) {
		// update details of student
		String q = "update employee set salary=? where empname=?";
		int msg = this.jdbctemp.update(q, emp.getSalary(), emp.getEmpname());

		return msg;
	}
	
	public int deletedetails(String empname) {
		String q="delete from employee where empname=?";
		int msg=this.jdbctemp.update(q,empname);
		return msg;
	}
	
	public List<Employee> getAllEmployeesRowMapper(){  
		 return jdbctemp.query("select * from employee",new RowMapper<Employee>(){  
		    public Employee mapRow(ResultSet rs, int rownumber) throws SQLException {  
		        Employee e=new Employee();  
		        e.setEmpname(rs.getString(1));  
		        e.setEmailid(rs.getString(2));
		        e.setDate(rs.getString(3));
		        e.setContactno(rs.getLong(4));
		        e.setSalary(rs.getFloat(5));  
		        return e;  
		    }  
		    });  
		}  

	

}
