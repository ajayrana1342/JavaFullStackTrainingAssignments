package com.yash.springjdbc.entities;

import java.time.LocalDate;

public class Employee {
	private String empname;
	private String emailid;
	private String date;
	private long contactno;
	private float salary;
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public long getContactno() {
		return contactno;
	}
	public void setContactno(long contactno) {
		this.contactno = contactno;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empname=" + empname + ", emailid=" + emailid + ", date=" + date + ", contactno=" + contactno
				+ ", salary=" + salary + "]";
	}
	public Employee(String empname, String emailid, String date, long contactno, float salary) {
		super();
		this.empname = empname;
		this.emailid = emailid;
		this.date = date;
		this.contactno = contactno;
		this.salary = salary;
	}
	public Employee() {
		super();
	}
	
	

}
