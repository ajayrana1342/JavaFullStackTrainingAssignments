
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.io.*;

public class DeleteFromTable
{

	public static void main(String[] args)
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null) 
			{
				System.out.println("connection is created successfully");
			}
			else 
			{
				System.out.println("connection is not created");
			}
			String q="select* from employee";
			PreparedStatement st=con.prepareStatement("delete from employee where empId=?");
			//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			//System.out.println("enter id");
			//int id=Integer.parseInt(br.readLine());
			//System.out.println("enter name");
			//String name=br.readLine();
			
			st.setInt(1,101);
			//st.setString(2,"ajay");
			int i=st.executeUpdate();
			System.out.println("records updated");
			
			ResultSet set=st.executeQuery(q);
			while(set.next()) 
			{
				int id1=set.getInt("empId");
				String name1=set.getString("name");
				System.out.println("id1 -"+id1);
				System.out.println("name1 -"+name1);
			}
			con.close();
		}
		catch(Exception e )
		{
			e.printStackTrace();
		}
		
	}
}

