
public class JdbcCollableState
{

}
