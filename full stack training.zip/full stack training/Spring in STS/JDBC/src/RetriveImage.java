import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;

public class RetriveImage {

	public static void main(String[] args)
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			PreparedStatement ps=con.prepareStatement("select * from imag ");
	        ResultSet r=ps.executeQuery();
	        if(r.next())
	        {
	        	Blob b=r.getBlob(2);
	        	byte barr[]=b.getBytes(1,(int)b.length());  
	              
	        	FileOutputStream fout=new FileOutputStream("d:\\image.jpg");  
	        	fout.write(barr);  
	        	              
	        	fout.close();  

	        }
	        System.out.println("done"); 
	         con.close();
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		

		

	}

}
