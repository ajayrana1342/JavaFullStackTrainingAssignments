import java.sql.*;
import java.io.*;

public class ImageStore {

	public static void main(String[] args) 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			PreparedStatement ps=con.prepareStatement("insert into imag values(?,?)");
	        ps.setString(1, "mountain");
	        
	        FileInputStream f=new FileInputStream("d:\\mountain.jpg");
	        ps.setBinaryStream(2,f,f.available());
	        int i=ps.executeUpdate();
	        System.out.println("updated");
	        con.close();
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		

	}

}
