class UncheckedExcepDemo
 {
	 public static void main(String args[])
	  {   try
	  {   
	      
		  int a=100;
		  int b=0;
		  int c=a/b;
		  
	  }
	  catch(ArithmeticException e)
	  {
		  e.printStackTrace();
	  }  
	  try{
	     String s=null;
	  int x=s.length();}
	  catch(NullPointerException e)
	  {
		  e.printStackTrace();
	  }
	  try
	  {
		  Object o=new Object();
		  String p=(String)o;
	  }
	  catch(ClassCastException e)
	  {
		  e.printStackTrace();
	  }
	  try
	   {
		   String t="AJAY";
		   System.out.println(t.charAt(t.length()+1));
	   }
	   catch(StringIndexOutOfBoundsException e)
	    {
			e.printStackTrace();
		}
	    try
		{
			int q=Integer.parseInt("");
		}
		catch(NumberFormatException e)
		 {
			 e.printStackTrace();
		 }
	  }
 }
