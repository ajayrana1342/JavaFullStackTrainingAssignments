import java.util.logging.Logger;

public class LoggerDemo
{
	private static final Logger log=Logger.getLogger(LoggerDemo.class);
	public void getdetails(){}
	

}
