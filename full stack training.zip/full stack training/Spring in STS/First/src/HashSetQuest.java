import java.util.HashSet;
public class HashSetQuest {
 HashSet<String> h1=new HashSet<String<>;
 
 public void saveCountryNames(String CountryName) 
  {
	 h1.add(CountryName);
  }
 public String getCountry(String CountryName) 
  {
	 if(h1.contains(CountryName)) {return CountryName;}
	 else {return null;}
  }
 
}
public class Test
 {
	public static void main(String args[]) 
	{
		HashSetQuest h=new HashSetQuest();
		h.saveCountryNames("India");
		h.saveCountryNames("Japan");
		h.saveCountryNames("Russia");
		h.getCountry("India");
		
	}
 }
