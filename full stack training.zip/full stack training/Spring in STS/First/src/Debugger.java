
public class Debugger {
  public static void main(String[] args) {
	System.out.println("AJAY RANA");
	int a=1;
	for(a=1;a<10;a++) {
	 System.out.println(a);}
}
}
