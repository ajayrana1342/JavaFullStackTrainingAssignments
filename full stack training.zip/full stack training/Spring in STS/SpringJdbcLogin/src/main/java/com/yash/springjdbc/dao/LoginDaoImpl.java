package com.yash.springjdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.entities.Employee;
import com.yash.springjdbc.entities.Login;

public class LoginDaoImpl implements LoginDao{
	private JdbcTemplate jdbctemp;

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int insert(Login emp) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public int insert(Login emp) {

		String q = "insert into employee(id) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getEmpname(), emp.getEmailid(),emp.getDate(),emp.getContactno(),emp.getSalary());
		return msg;
	}
	

}
