package com.yash.springjdbc;

public class App {

}
