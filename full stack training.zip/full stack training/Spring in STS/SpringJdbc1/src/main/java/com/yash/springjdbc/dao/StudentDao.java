package com.yash.springjdbc.dao;



import com.yash.springjdbc.entities.Student;



public interface StudentDao {

public int insert(Student stu);
public int updatedetails(Student stu);
public int deletedetails(int id);
public Student selectDetails(int id);




}