import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class LocatDateDemo 
{
	public static void main(String[] args) 
	{
		LocalDate d=LocalDate.now();
		System.out.println(d);
		LocalDate ytd=d.minusDays(1);
		System.out.println(ytd);
		LocalDate tmr=d.plusDays(1);
		System.out.println(tmr);
		LocalDate after15=d.plusDays(15);
		System.out.println(after15);
		
		LocalDate d1=LocalDate.of(2022, 4, 20);
		System.out.println(d1);
		System.out.println(d1.isLeapYear());
	
		String s=d1.format(DateTimeFormatter.BASIC_ISO_DATE);
		System.out.println(s);
		String s1="2020-11-20";
		LocalDate d3=LocalDate.parse(s1);
		System.out.println(d3);
		
		System.out.println(d.equals(d1));
		System.out.println(d1.compareTo(d));
		
		
		
		
	}

}
