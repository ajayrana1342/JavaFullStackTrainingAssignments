import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class SubStringExtract
{
	public static void main(String[] args)
	{
		String s="hello world 'Happy' all are you";
		Pattern p=Pattern.compile("'(.*?)'");
		Matcher m=p.matcher(s);
		if(m.find()) 
		{
			System.out.println(m.group());
		}
		
	}
	

}
