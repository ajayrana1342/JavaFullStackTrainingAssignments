
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class StringSplitNewline
{ public static void main(String[] args) 
 {
	

	Scanner sc=new Scanner(System.in);
	String s=sc.nextLine();
	String lines[]=s.split("\\r?\\n");
     for(String t:lines) 
     {
    	 System.out.println(t);
     }
 }
}
