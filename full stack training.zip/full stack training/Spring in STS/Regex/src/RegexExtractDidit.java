import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexExtractDidit
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String regex="\\d+";
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(s);
		System.out.println("digits int the given string are:-");
		while(m.find()) 
		{
			System.out.println(m.group()+" ");
		}
		
	}

}
