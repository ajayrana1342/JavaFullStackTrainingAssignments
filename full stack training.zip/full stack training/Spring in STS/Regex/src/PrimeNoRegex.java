import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class PrimeNoRegex
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println(PrimeNoRegex.prime(n));

		
	}
	public static boolean prime(int n) 
	{
		return !new String(new char[n]).matches(".?|(..+?)\\1+");
	}

}
