import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class RegexAssignment
{
	public static void main(String[] args)
	{
		
		System.out.println(Pattern.matches("[0-9]{10}","1234567890"));

		System.out.println(Pattern.matches("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$","yash@.com"));
		
		System.out.println(Pattern.matches("^[https:]+[a-zA-Z0-9.-]+$","https:yash.com"));
		
		
	}

}

