class ThisReturn
 {
   
  public static void main(String args[])
  {
    ThisReturn1 t=new ThisReturn1();
	//t.add();
  }
 }
 
class ThisReturn1
  {
	
    ThisReturn1 add()
	{
	return this;
	}
	
	ThisReturn1()
	{   
		System.out.println("Hello");
	}
  }