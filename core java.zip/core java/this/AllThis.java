class AllThis
  {
    void t1(AllThis t)
	{
		Hello h= new Hello(this);
		
	System.out.println("In t1");
	}
	void t2()
	{ 
	  t1(this);
	 System.out.println("In t2");
	}
	
   AllThis()
   { 
   System.out.println("AllThis no argument constructor");
   }
   AllThis(int a)
   { this();
      System.out.println(" AllThis parameterized constructor");
   }
	 public static void main(String args[])
	{
	  AllThis t=new AllThis(10);
	  t.t2();
	  
	}
  }
  
class Hello
  {
	  Hello(AllThis t)
	  {
		  System.out.println("Hello constructor");
		  
	  }
  }
  

