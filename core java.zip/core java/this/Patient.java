class Patient
 {
   String patientName;
   double h;
   double w;
   Patient(String s,double h,double w)
   {
    this.patientName=s;
	this.h=h;
	this.w=w;
   }
   double computeBMI()
   {
    double z=w/(h*h);
	return z;
   }
   public static void main(String args[]){
   Patient p=new Patient("ajay",6,50);
   System.out.println(p.computeBMI());
   
   }
 
 
 }