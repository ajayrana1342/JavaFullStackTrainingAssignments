class Box
 {  
   double h;
   double w;
   double d;
   Box(double h,double w,double d)
   {
    this.h=h;
	this.w=w;
	this.d=d;
   }
   public double volume()
   {
     double z=h*w*d;
	 return z;
   }
   
   
   
 }
 class Box1
 { 
   public static void main(String args[])
   {  
    Box b=new Box(4,3,2);
	double t=b.volume();
	System.out.println(t);
   }
 }