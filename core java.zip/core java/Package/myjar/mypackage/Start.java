package mypackage;
public class Start
 {
	 public void display()
	  {
		  System.out.println("i am in display-start class");
	  }
	  
 }