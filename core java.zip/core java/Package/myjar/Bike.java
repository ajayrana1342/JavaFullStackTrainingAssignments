import firstpackage.Vehicle;
class Bike
{ public static void main(String args[])
   {
     Vehicle v=new Vehicle();
	  v.show();
   }
}