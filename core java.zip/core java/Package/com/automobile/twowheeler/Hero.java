package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Hero extends Vehicle
 {
	 public int getSpeed()
	 {   
		 return 60;
	 }
	 public void radio()
	 {
		 System.out.println("Provide radio service");
	 }
	 public String getModelName()
	 { return "PassionPro"; }
	 public String getRegistrationNumber()
	 { return "4647";}
	 public String getOwnerName()
	 {return "AJAY";}
 }