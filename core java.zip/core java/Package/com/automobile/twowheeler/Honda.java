package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Honda extends Vehicle
 {
	 public int getSpeed()
	 {
		 return 100;
	 }
	 public void cdPlayer()
	 {
		 System.out.println("Provide cdplayer service");
	 }
	 public String getModelName()
	 {return "Shine";}
	 public String getRegistrationNumber()
	 {return "748";}
	 public String getOwnerName()
	 {return "AJAY";}
 }