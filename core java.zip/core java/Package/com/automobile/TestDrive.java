package com.automobile;
import com.automobile.Vehicle;
import com.automobile.twowheeler.*;

class TestDrive
 {
	 public static void main(String args[])
	 {
		 Hero h=new Hero();
		System.out.println( h.getModelName());
		System.out.println(  h.getRegistrationNumber());
		 System.out.println( h.getOwnerName());
		 System.out.println( h.getSpeed());
		 h.radio();
		 Honda H=new Honda();
		 System.out.println( H.getModelName());
		System.out.println(  H.getRegistrationNumber());
		 System.out.println( H.getOwnerName());
		 System.out.println( H.getSpeed());
		 H.cdPlayer();
		 
	 }
 }