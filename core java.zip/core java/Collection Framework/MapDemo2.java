import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.*;
class MapDemo2
 {
	 public static void main(String args[])
	  {
		 
		   HashMap<Integer,String> m1=new HashMap<Integer,String>();
          m1.put(10,"yash");
		  m1.put(20,"Ajay");
		  m1.put(30,"Ayush");
		  System.out.println(m1);
		  
		  int key=50;
		  boolean isKey=m1.containsKey(key);
		  System.out.println("key exits:- "+isKey);
		  String s="Ajay";
		  boolean isvalue=m1.containsValue(s);
		  System.out.println("key exits:- "+isvalue);
		
		  Iterator<Map.Entry<Integer,String>> i=m1.entrySet().iterator();
		  while(i.hasNext())
		  {
			  Map.Entry<Integer,String> e=i.next();
			  System.out.println(e);
		  }
		  
		  

	  }
 }