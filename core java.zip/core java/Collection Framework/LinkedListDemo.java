import java.util.LinkedList;
import java.util.Iterator;
class LinkedListDemo
 {
	 public static void main(String args[])
	  {
		  LinkedList<String> a=new LinkedList<String>();
		  a.add("January");
		  a.add("february");
		  a.add("March");
		  a.add("April");
		  a.add("May");
		  a.add("Jun");
		  a.add("July");
		  a.add("August");
		  a.add("September");
		  a.add("October");
		  a.add("November");
		  a.add("December");
		  System.out.println(a);
		  System.out.println("");
		  for(String x:a)
		  {
			  System.out.println(x);
		  }
		  System.out.println("");
		  Iterator i=a.iterator();
		  while(i.hasNext()){
		   
		   System.out.println(i.next());
		   }
      
	  }
 }