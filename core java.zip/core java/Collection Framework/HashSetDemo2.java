import java.util.HashSet;
import java.util.Iterator;
class HashSetDemo2
 {
	 public static void main(String args[])
	  {
		  HashSet<String> a=new HashSet<String>();
		  a.add("Ravi");
		  a.add("Vijay");
		  a.add("hritik");
		  a.add("sanjay");
		  a.add("kapil");
		  a.add("deepak");
		  a.add("mahima");
		  System.out.println(a);
		  
		 Iterator i=a.iterator();
		 while(i.hasNext()){System.out.println(i.next());}
		 System.out.println("");
		 
		  
		 
	  }
 }