import java.util.Vector;
import java.util.Iterator;
import java.util.Enumeration;
class VectorEmployee
 {   
     static class Employee
	  {
		  String name;
		  int empid;
		  float salary;
		  Employee(String name,int empid,float salary)
		  {
			  this.name=name;
			  this.empid=empid;
			  this.salary=salary;
		  }
	  }
	  
	 public static void main(String args[])
	  {
		  Vector<Employee> a=new Vector<Employee>();
		   a.add(new Employee("AJAY",1014,1000000));
		   a.add(new Employee("Ayush",1014,1000000));
		   
		  System.out.println(a.toString());
		  System.out.println("");

		  System.out.println("");
		  Iterator i=a.iterator();
		  while(i.hasNext()){
		   
		   System.out.println((Employee)i.next());
		   }
       Enumeration m=a.elements();
	  while(m.hasMoreElements())
	   {
		   System.out.println((Employee)m.nextElement());
	   }
	  }
 }