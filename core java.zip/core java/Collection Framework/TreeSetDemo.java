import java.util.TreeSet;
import java.util.Iterator;
class TreeSetDemo
 {
	 public static void main(String args[])
	  {
		  TreeSet<String> a=new TreeSet<String>();
		  a.add("Ravi");
		  a.add("Vijay");
		  a.add("hritik");
		  a.add("sanjay");
		  a.add("kapil");
		  a.add("deepak");
		  a.add("mahima");
		  System.out.println(a.descendingSet());
		  
		 Iterator i=a.iterator();
		 while(i.hasNext()){System.out.println(i.next());}
		 System.out.println(a.contains("AJAY"));
		 
		  
		 
	  }
 }