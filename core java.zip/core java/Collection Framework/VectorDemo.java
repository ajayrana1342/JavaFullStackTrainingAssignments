import java.util.Vector;
import java.util.Iterator;
import java.util.Enumeration;
class VectorDemo
 {
	 public static void main(String args[])
	  {
		  Vector<String> a=new Vector<String>();
		  a.add("January");
		  a.add("february");
		  a.add("March");
		  a.add("April");
		  a.add("May");
		  a.add("Jun");
		  a.add("July");
		  a.add("August");
		  a.add("September");
		  a.add("October");
		  a.add("November");
		  a.add("December");
		  System.out.println(a);
		  System.out.println("");
		  for(String x:a)
		  {
			  System.out.println(x);
		  }
		  System.out.println("");
		  Iterator i=a.iterator();
		  while(i.hasNext()){
		   
		   System.out.println(i.next());
		   }
       Enumeration m=a.elements();
	  while(m.hasMoreElements())
	   {
		   System.out.println(m.nextElement());
	   }
	  }
 }