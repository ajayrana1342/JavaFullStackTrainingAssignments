import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
class MyArrayList<E> extends ArrayList<E>
 {
	 public boolean add(E e)
	 {
		 if(e instanceof Integer || e instanceof Float || e instanceof Double)
		 {
			 super.add(e);
			 return true;
		 }
		 else{throw new ClassCastException("Only,Integer,Float and double are supported");}
	 }
 }

public class ArrayListStore
 {
	 public static void main(String args[])
	  {
		  List<Object> a=new MyArrayList<>();
		  try{
		  a.add(10);
		  a.add(1.8F);
		  a.add(15D);
		  a.add("Hello");
		  }
		  catch(Exception e){
			  e.printStackTrace();
		  }
		  Iterator i=a.iterator();
		  System.out.println(a);
		  while(i.hasNext())
		  {
			  System.out.println(i.next());
		  }
	  }
 }