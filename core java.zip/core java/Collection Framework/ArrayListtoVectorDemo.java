import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Vector;
class ArrayListtoVectorDemo
 {
	 public static void main(String args[])
	  {
		  ArrayList<String> a=new ArrayList<String>();
		  a.add("January");
		  a.add("february");
		  a.add("March");
		  a.add("April");
		  a.add("May");
		  a.add("Jun");
		  a.add("July");
		  a.add("August");
		  a.add("September");
		  a.add("October");
		  a.add("November");
		  a.add("December");
		  Vector<String> v=new Vector<String>(a);
		  
		  System.out.println(v);
		  
		 ListIterator li=v.listIterator();
		 while(li.hasNext()){System.out.println(li.next());}
		 System.out.println("");
		 while(li.hasPrevious()){
		 System.out.println(li.previous());}
		 System.out.println("");
		 
		 li.set("Hello");
		 while(li.hasNext()){System.out.println(li.next());}
		 
		  
		 
	  }
 }