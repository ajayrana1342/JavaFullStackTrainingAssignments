import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.ArrayList;
class HashMapQuest {
 HashMap<String,String> h1=new HashMap<String,String>();
 Iterator<Map.Entry<String,String>> i=h1.entrySet().iterator();
 
 public void saveCountryCapital(String CountryName,String capital) 
  {
	 h1.put(CountryName,capital);
  }
 public String getCapital(String CountryName) 
  {
	 if(h1.containsKey(CountryName)) {return h1.get(CountryName);}
	 else {return null;}
  }
   public String getCountry(String capital) 
  {
	  
	 		  for(Map.Entry map:h1.entrySet())
		  {
			  if(capital.equals(map.getValue())){return (String)map.getKey();}
			  
		  }
	 return null;
  }
  public String reverse()
  {
	  HashMap<String,String> h2=new HashMap<String,String>();
	  for(Map.Entry entry: h1.entrySet())
	  {
		  h2.put((String)entry.getValue(),(String)entry.getKey());
	  }
	  return h2.toString();
  }
  public String arrayList()
   {
	   ArrayList<String> a =new ArrayList<String>();
	   	  for(Map.Entry entry: h1.entrySet())
	  {
		  a.add((String)entry.getKey());
	  }
	  return a.toString();
	
   }
  
  
 
}
class HashMapMain
 {
	public static void main(String args[]) 
	{
		HashMapQuest h=new HashMapQuest();
		h.saveCountryCapital("India","Delhi");
		h.saveCountryCapital("Japan","Tokyo");
		h.saveCountryCapital("Russia","Moscow");
		System.out.println(h.getCountry("Delhi"));
		System.out.println(h.getCapital("India"));
		System.out.println(h.reverse());
		System.out.println(h.arrayList());
	}
 }
