import java.util.ArrayList;
class ArrayListDemo
 {
	 public static void main(String args[])
	  {
		  ArrayList<String> a=new ArrayList<String>();
		  a.add("Ajay");
		  a.add("Ayush");
		  a.add("Hritik");
		  for(String x:a)
		  {
			  System.out.println(x);
		  }

	  }
 }