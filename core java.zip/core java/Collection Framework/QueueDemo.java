import java.util.Queue;
import java.util.PriorityQueue;
import java.util.LinkedList;
class QueueDemo
 {
	 public static void main(String args[])
	  {
		  Queue<Integer> pq=new PriorityQueue<Integer>();
		  pq.add(10);
		  pq.add(5);
		  pq.add(20);
		  System.out.println(pq);
		  System.out.println(pq.peek());
		  System.out.println(pq.poll());
		  System.out.println(pq.peek());
		  System.out.println(pq);
		  Queue<Integer> li=new LinkedList<Integer>();
		  li.add(50);
		  li.add(100);
		  li.add(150);
		  System.out.println(li);
		  System.out.println(li.peek());
		  System.out.println(li.poll());
		  System.out.println(li.peek());
		  System.out.println(li);
		  

	  }
 }