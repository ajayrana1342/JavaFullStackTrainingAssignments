import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.*;
class MapContactList
 {
	 public static void main(String args[])
	  {
		 
		   HashMap<String,Integer> m1=new HashMap<String,Integer>();
          m1.put("Ayush",1338);
		  m1.put("Ajay",1252);
		  m1.put("Sourav",36733);
		  System.out.println(m1);
		  
		  String key="Ajay";
		  boolean isKey=m1.containsKey(key);
		  System.out.println("key exits:- "+isKey);
		  int s=1252;
		  boolean isvalue=m1.containsValue(s);
		  System.out.println("key exits:- "+isvalue);
		
		  Iterator<Map.Entry<String,Integer>> i=m1.entrySet().iterator();
		  while(i.hasNext())
		  {
			  Map.Entry<String,Integer> e=i.next();
			  System.out.println(e);
		  }
		  
		  

	  }
 }