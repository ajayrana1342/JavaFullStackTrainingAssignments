import java.util.HashSet;
import java.util.Iterator;
class HashSetDemo
 {
	 public static void main(String args[])
	  {
		  HashSet<String> a=new HashSet<String>();
		  a.add("January");
		  a.add("february");
		  a.add("March");
		  a.add("April");
		  a.add("May");
		  a.add("Jun");
		  a.add("July");
		  a.add("August");
		  a.add("September");
		  a.add("October");
		  a.add("November");
		  a.add("January");
		  System.out.println(a);
		  
		 Iterator i=a.iterator();
		 while(i.hasNext()){System.out.println(i.next());}
		 System.out.println("");
		 
		  
		 
	  }
 }