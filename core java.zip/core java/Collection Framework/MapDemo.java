import java.util.HashMap;
import java.util.Map;;
import java.util.Set;
import java.util.Iterator;
import java.util.*;
class MapDemo
 {
	 public static void main(String args[])
	  {
		  Map m=new HashMap();
          m.put(10,"yash");
		  m.put(5,"Technologies");
		  m.put(30,"Indore");
		  System.out.println(m);
		  Set s=m.entrySet();
		  Iterator i=s.iterator();
		  while(i.hasNext())
		  {
			  Map.Entry entry=(Map.Entry)i.next();
			  System.out.println("key "+entry.getKey()+" value "+entry.getValue());
		  }
		   Map<Integer,String> m1=new HashMap<Integer,String>();
          m1.put(10,"yash");
		  m1.put(20,"Ajay");
		  m1.put(30,"Ayush");
		  System.out.println(m1);
		  for(Map.Entry map:m1.entrySet())
		  {
			  System.out.println("key "+map.getKey()+" "+"value "+map.getValue());
			  
		  }
		  ArrayList<Integer> a=new ArrayList(m.keySet());
		  Collections.sort(a);
		  System.out.println(a);
		  ArrayList<String> b=new ArrayList<String>(m.values());
		  Collections.sort(b);
		  System.out.println(b);
		  
		  
		  

	  }
 }