class MinMax
{
   public static void main(String args[])
   {
     int a[]=new int[]{1,2,3,4,5};
	 //int b[][]=new int[][]{{1,2,3,4,5},{1,5,9}};
	 
	  int max=a[0];
	  int min=a[0];
	  for(int i=0;i<a.length;i++)
	  {  if(a[i]>a[max]) max=i;
	  
	  }
	   for(int i=0;i<a.length;i++)
	  {  if(a[i]<a[min]) min=i;
	  
	  }
	  System.out.println(a[max]+" "+a[min]);
	 
   
   }
   
   
   
}