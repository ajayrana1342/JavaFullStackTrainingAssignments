class RemoveDub
{
   public static void main(String args[])
   {
     int a[]=new int[]{5,3,4,6,4,5,3,1};
	   int sum=0; int z=0;
	   int x,y;
     for(int i=0;i<a.length;i++)
	 {
		 if(a[i]==6){x=i;}
		 if(a[i]==7){y=i;}
		 
	 }
	 for(int i=0;i<a.length;i++)
	 {
		 if(x<y){
			 for(int j=x;j<=y;j++)
			 {z=z+a[j];}
		 }
		 sum=sum+a[i];
		 
	 }
	 System.out.println(sum-z);
	  
	  
	  
	  
	 
   
   }
}