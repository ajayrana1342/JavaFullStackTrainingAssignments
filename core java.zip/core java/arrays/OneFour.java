class Onefour
{
   public static void main(String args[])
   {
     int a[]=new int[]{1,1,4};
	 int k=1;
	 for(int i=0;i<a.length;i++)
	 {
	   if((a[i]!=1) && (a[i]!=4))
	   {
	    System.out.println("FALSE");
		k=0;
		break;
	   }
	 
	 }
	 if(k==1)System.out.println("True");
	 
	 
    }
}