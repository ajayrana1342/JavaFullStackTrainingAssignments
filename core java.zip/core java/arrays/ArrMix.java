class ArrMix
{
   public static void main(String args[])
   {
      int x[]={1,2,3};
	  int y[]={4,5,6};
	  int z[]=new int[2];
	  z[0]=x[1];
	  z[1]=y[1];
	  for(int k:z){
	  System.out.println(k);}

   
   }
}