class Sumbtw
{
   public static void main(String args[])
   {
     int a[]=new int[]{10,5,6,5,2,7,9};
	   int sum=0; int z=0;
	   int x=0,y=0;
     for(int i=0;i<a.length;i++)
	 {
		 if(a[i]==6){x=i;}
		 if(a[i]==7){y=i;}
		 
	 }
	  if(x<y){
			 for(int j=x;j<=y;j++)
			 {z=z+a[j];}
		 }
	 
	 for(int i=0;i<a.length;i++)
	 {
		
		 sum=sum+a[i];
		 
	 }
	 System.out.println(sum-z);
	  
	  
	  
	  
	 
   
   }
}