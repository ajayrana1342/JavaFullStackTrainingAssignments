class SortedArray
{
   public static void main(String args[])
   {
     int a[]=new int[]{5,3,4,6,1};
	 //int b[][]=new int[][]{{1,2,3,4,5},{1,5,9}};
      
	  for(int i=0;i<a.length;i++)
	  {
	    for(int j=i+1;j<a.length;j++)
		{  int temp=0;
		   if(a[i]>a[j]){
		     temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		   }		
		}
	  }
	  
	  for(int i:a)
	  {
	  System.out.println(i);}
	  
	  
	 
   
   }
}