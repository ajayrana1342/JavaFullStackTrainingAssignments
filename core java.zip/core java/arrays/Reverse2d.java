class Revere2D
{
   public static void main(String args[])
   {
     int  a[][]=new int[2][2];
	  int k=0;
     for(int i=0;i<2;i++)
	 {  for(int j=0;j<2;j++)
	   a[i][j]=Integer.parseInt(args[k]);
	   k++;
	 }
	 
	 for(int x[]:a)
	 {
	  for(int y:x){System.out.println(y);}
	 }
   
   }
}