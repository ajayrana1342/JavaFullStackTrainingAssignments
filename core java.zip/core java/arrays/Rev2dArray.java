class Rev2dArray
{
   public static void main(String args[])
   {
     int  a[][]=new int[2][2];
      int p=args.length;
	  if(p<4){System.out.println("please enter 4 numbers");}
	  
	  int k=0;
     for(int i=0;i<2;i++)
	 {  for(int j=0;j<2;j++){
	   a[i][j]=Integer.parseInt(args[k]);
	 k++;}
	 }
	 
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			System.out.print(a[1-i][1-j]+" ");
		}
		System.out.println();
	}
   
   }
}