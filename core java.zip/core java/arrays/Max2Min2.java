class Max2Min2
{
   public static void main(String args[])
   {
     int a[]=new int[]{1,2,3,4,5};
	
	  for(int i=0;i<a.length;i++)
	  {
	    for(int j=i+1;j<a.length;j++)
		{  int temp=0;
		   if(a[i]>a[j]){
		     temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		   }		
		}
	  }
	   System.out.println(a[0]+" "+a[1]);
	   	   System.out.println(a[a.length-1]+" "+a[a.length-2]);

	  
   
   }
   
   
   
}