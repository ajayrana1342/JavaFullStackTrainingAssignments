class ArraySum
{
   public static void main(String args[])
   {
     int a[]=new int[]{1,2,3,4,5};
	 int b[][]=new int[][]{{1,2,3,4,5},{1,5,9}};
	 
	 
	 int sum=0;
	 for(int i:a){
	 sum=sum+i;}
	 int avg=0;
	 avg=sum/2;
	 System.out.println(sum+" "+avg);
	 
	 
	  int sum1=0;
	 for(int j[]:b){
		for(int k:j){ 
		sum1=sum1+k;}
	 }
	 int avg1=0;
	 avg1=sum1/2;
	 System.out.println(sum1+" "+avg1);
   
   }
   
   
   
}