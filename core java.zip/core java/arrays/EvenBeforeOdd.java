class EvenBeforeOdd
{
   public static void main(String args[])
   {
      int a[]={1,2,3,4,5,6,7,8};
	  int b[]=new int[a.length];
	  int k=0;
	  for(int i=0;i<a.length;i++)
	  {
	   if(a[i]%2==0){b[k]=a[i];k++;}
	  }
	  for(int i=0;i<a.length;i++)
	  {
	  if(a[i]%2!=0){b[k]=a[i];k++;}
	  }
	  for(int t:b)
	  {System.out.println(t);
	  }
	  

   
   }
}