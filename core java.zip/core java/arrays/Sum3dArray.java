class Sum3dArray
{
   public static void main(String args[])
   {
      int t=0;
	  int max=Integer.MIN_VALUE;
     int a[][]=new int[3][3];
     for(int i=0;i<3;i++)
	 {
         for(int k=0;k<3;k++){
	   a[i][k]=Integer.parseInt(args[t]);
	   t++;
	   if(a[i][k]>max){max=a[i][k];}
	   
	 }
	 }
	 System.out.println(max);
	 
	 

   
   }
}