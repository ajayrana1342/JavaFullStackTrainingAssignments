class ThisDemo
{ 
 void display()
 {
 System.out.println("YASH");
 }
  void show()
  {
   display();//if you don't use this keyword ,compiler automatically adds this keyword while invoking the method
  }
 public static void main(String args[])
 {  
    ThisDemo t=new ThisDemo();
	t.show();
 }
}