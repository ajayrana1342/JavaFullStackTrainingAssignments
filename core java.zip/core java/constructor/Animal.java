class Animal
{   
    void eat()
   {
   System.out.println("Eating");
   }
   public static void main(String args[])
   {
    Animal a=new Animal();
	a.eat();
	System.out.println("I am in main");
   }
}