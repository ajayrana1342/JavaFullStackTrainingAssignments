class Test
{
   Test(ThisDemo4 x)
   {  
     
     System.out.println("Test constructor");
   }
}

class ThisDemo4
{ 
   void add()
  {
	 Test x=new Test(this); 
   System.out.println("Y1 method");
  }

 public static void main(String args[])
 {  
    ThisDemo4 t=new ThisDemo4();
	t.add();
    
 }
}