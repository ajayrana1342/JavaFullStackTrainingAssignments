class Democonstructor
{
	String name;
  Democonstructor()
  { System.out.println("Constructor");
  }
  Democonstructor(String name)
  {
    this.name=name;
	System.out.println(this.name);
  }
    
 public static void main(String args[])
 {
   Democonstructor d=new Democonstructor();
   Democonstructor d1=new Democonstructor("Hello");
    
 }
}