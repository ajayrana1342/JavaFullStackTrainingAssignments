class ThisDemo2
{ 
 ThisDemo2()
 {  this(10);
   System.out.println("NO argument constructor");
   
 }
  ThisDemo2(int a)
  {  // this();
    System.out.println("Parameterised constructor"); 
  }

 public static void main(String args[])
 {  
    ThisDemo2 t=new ThisDemo2();
	
 }
}