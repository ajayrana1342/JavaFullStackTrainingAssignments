class ThisDemo3
{ 
  void y1(ThisDemo3 t)
  {
  System.out.println("Y1 method");
  }
  
  void y2()
  { //y1(this);
    System.out.println("Y2 method");
	y1(this);
  }

 public static void main(String args[])
 {  
    ThisDemo3 t=new ThisDemo3();
	t.y2();
 }
}