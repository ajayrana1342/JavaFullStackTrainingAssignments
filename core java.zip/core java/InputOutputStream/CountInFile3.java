import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
class CountInFile3
 {
	 public static void main(String args[])
	  {  try{
		  FileInputStream f=new FileInputStream("d:/yash/abc.txt");
		  int y=0;
		  byte[] bu=new byte[f.available()];
		  f.read(bu);
		  String data=new String(bu);
		  Scanner sc=new Scanner(System.in);
		  char c=sc.next().charAt(0);
	      for(int k=0;k<data.length();k++)
		  {
			if(data.charAt(k)==c){y++;}  
		  }
		 System.out.println("no of times "+c+" character appears "+ y); 
		 
	  }
	  		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	  }
 }