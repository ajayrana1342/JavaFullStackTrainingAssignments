import java.io.FileInputStream;
import java.io.IOException;
class CountInFile2
 {
	 public static void main(String args[])
	  {  try{
		  FileInputStream f=new FileInputStream("d:/yash/abc.txt");
		  int c;
		  int y=0;
		  byte[] bu=new byte[f.available()];
		  f.read(bu);
		  String data=new String(bu);
		  int a=0,e=0,i=0,o=0,u=0;
	      for(int k=0;k<data.length();k++)
		  {
			  if(data.charAt(k)=='a'|| data.charAt(k)=='A')
			  {y++;
		      a++;}
			 if(data.charAt(k)=='e'|| data.charAt(k)=='E'){y++;e++;}
			  if(data.charAt(k)=='i'|| data.charAt(k)=='I'){y++;i++;}
			if(data.charAt(k)=='o'|| data.charAt(k)=='O'){y++;o++;}
			if(data.charAt(k)=='u'|| data.charAt(k)=='U'){y++;u++;}
		  }
		  System.out.println("Total no of vowel="+y);
		  System.out.println("Total no of vowel a="+a);
		  System.out.println("Total no of vowel e"+e);
		  System.out.println("Total no of vowel i"+i);
		  System.out.println("Total no of vowel o"+o);
		  System.out.println("Total no of vowel u"+u);
		 
	  }
	  		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	  }
 }