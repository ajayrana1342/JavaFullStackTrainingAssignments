import java.io.ByteArrayInputStream;
import java.io.IOException;
class ByteArrayInputDemo
 {
	 public static void main(String args[])
	  {  try{
		  byte[] bu={1,2,3,4};
		  ByteArrayInputStream b=new ByteArrayInputStream(bu);
		 
		  int i;
		  while((i=b.read())!=-1)
		   {   
			   System.out.print(i);
		   }
		  
		   b.close();
		
	      }
		  catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	  }
 }