import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
class DataInputDemo
 {
	 public static void main(String args[])
	  {
		  try
		   {
			   FileInputStream f=new FileInputStream("d:/yash/abc.txt");
			   DataInputStream d=new DataInputStream(f);
			   int c=f.available();
			   byte[] bu=new byte[c];
			   d.read(bu);
			   for(byte bt:bu)
			    {
				  System.out.println((char)bt);
				}
			   f.close();
			   d.close();
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	  }
 }