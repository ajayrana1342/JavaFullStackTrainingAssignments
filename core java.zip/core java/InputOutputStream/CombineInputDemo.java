import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.SequenceInputStream;
class CombineInputDemo
 {
	 public static void main(String args[])
	  {  try{
		  FileInputStream f1=new FileInputStream("d:/yash/abc.txt");
		  FileInputStream f2=new FileInputStream("d:/yash/xyz.txt");
		  FileOutputStream combine=new FileOutputStream("d:/yash/combine.txt");
		  SequenceInputStream s=new SequenceInputStream(f1,f2);
		  int i;
		  while((i=s.read())!=-1)
		   {   combine.write(i);
			   System.out.print((char)i);
		   }
		   f1.close();
		   f2.close();
		   combine.close();
		
	      }
		  catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	  }
 }