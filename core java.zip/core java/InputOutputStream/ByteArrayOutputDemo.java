import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class ByteArrayOutputDemo
 {
	 public static void main(String args[])
	  {  try{
		  String s="Hello world";
		  ByteArrayOutputStream b=new ByteArrayOutputStream();
		  FileOutputStream f1=new FileOutputStream("d:/yash/xyz.txt");
		  FileOutputStream f2=new FileOutputStream("d:/yash/abc.txt");
		  byte[] bu=s.getBytes();
		  b.write(bu);
		  b.writeTo(f1);
		  b.writeTo(f2);
		  b.flush();
		  b.close();
		  f1.close();
		  f2.close();
	      }
		  catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	  }
 }