import java.io.FileInputStream;
import java.io.IOException;
class CountInFile
 {
	 public static void main(String args[])
	  {  try{
		  FileInputStream f=new FileInputStream("d:/yash/abc.txt");
		  int c;
		  int x=0,y=0;
		  byte[] bu=new byte[f.available()];
		  f.read(bu);
		  String data=new String(bu);
		  String[] st=data.split("\r\n");
		  System.out.println("Number of line"+st.length);
	      for(int i=0;i<data.length();i++)
		  {
			  if(data.charAt(i)==' '){y++;}
		  }
		 System.out.println("Number of characters"+data.length());
		 System.out.println("Number of spaces"+" "+(y));
		 System.out.println("Number of words"+(y+1));
	  }
	  		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	  }
 }