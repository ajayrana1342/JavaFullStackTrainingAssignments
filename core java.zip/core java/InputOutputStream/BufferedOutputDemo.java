import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputDemo
 {
	 public static void main(String args[])
	  {  try{
		  FileOutputStream f=new FileOutputStream("d:/yash/xyz.txt");
		  BufferedOutputStream b=new BufferedOutputStream(f);
           
		   String a="AJAY";
		   byte x[]=a.getBytes();
		   b.write(x);
		   b.flush();
		   f.close();
		   b.close();
	      }
		  catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	  }
 }