import java.io.*;
class BufferReaderDemo
 {
	 public static void main(String args[]) throws Exception
	 {
        String str;
		InputStreamReader r=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(r);
        
        str=br.readLine();	
        System.out.println(str);		
	 }
 }