 class Outer
{  static int a=10;
  static  void show1()
   {
	   System.out.println("Outer show");
   }
    static class Inner
  {
     void show()
	 {
	  System.out.println("inner show");
	  System.out.println(a);
	 }
  }
}
public class OuterDemo2
{
   public static void main(String args[])
   {    Outer.show1();
   //Outer o=new Outer();
	   Outer.Inner o1=new Outer.Inner();
	   o1.show();
   }
}