abstract class AnonymousInner
{
  public abstract void show();
}

public class OuterDemo3 
{
	public static void main(String args[])
	{
		AnonymousInner inner=new AnonymousInner()
		{
			public void show(){
				System.out.println("show method");
			}
		};
		inner.show();
	}
}