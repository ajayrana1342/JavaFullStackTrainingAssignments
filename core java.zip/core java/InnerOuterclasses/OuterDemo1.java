class Outer
{
  static class Inner
  {
     void show()
	 {
	  System.out.println("inner show");
	 }
  }
}
public class OuterDemo1
{
   public static void main(String args[])
   {
	   Outer.Inner o1=new Outer.Inner();
	   o1.show();
   }
}