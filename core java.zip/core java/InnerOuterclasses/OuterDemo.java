class Outer
{
  class Inner
  {
     void show()
	 {
	  System.out.println("inner show");
	 }
  }
}
public class OuterDemo
{
   public static void main(String args[])
   {
	   Outer o=new Outer();
	   Outer.Inner o1=o.new Inner();
	   o1.show();
   }
}