class ReverseNo{
public static void main(String args[]){

	String s=args[0];
	String x="";
	for(int i=s.length()-1;i>=0;i--){
	x=x+s.charAt(i);
	}
      System.out.println(x); 


}}