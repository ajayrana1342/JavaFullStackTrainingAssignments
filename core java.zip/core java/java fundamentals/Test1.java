class Test1 {
    public static void main (String args[]){
	  int a=Integer.parseInt(args[0]);
	  System.out.println(a);
	  float b= Float.parseFloat(args[1]);
	  System.out.println(b);
	  
	  char c= args[2].charAt(0);
	  System.out.println(c);
		  
	
	}


}