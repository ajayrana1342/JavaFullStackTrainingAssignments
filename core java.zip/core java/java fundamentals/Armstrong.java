class Armstrong{
public static void main(String args[]){
    String s=args[0];
    int n=s.length();
	
	int sum=0;
	int k=0;
	for(int i=0;i<n-1;i++){
	sum=s.charAt(i)*s.charAt(i)*s.charAt(i);
	k=sum;
	}
	System.out.println(k);  
	if(sum==Integer.parseInt(s)){System.out.println("Armstrong number");}
	else{System.out.println("Not a Armstrong number");}
   
   }
}