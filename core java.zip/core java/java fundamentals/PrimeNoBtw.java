class PrimeNoBtw{
     public static void main(String args[]){
	 int a=Integer.parseInt(args[0]);
	 int b=Integer.parseInt(args[1]);
	 int sum=0;
	 
	 
	 for(int i=a;i<b;i++){
	 for(int j=2;j<a;j++){
	 if(a%j!=0){System.out.println(a);sum=sum+a;break;}
	 
	 }
	 
	 
	 
	 
	 }
	 
	 System.out.println(sum);
	 
	 
	 
	 
	 
	 
	 }



}