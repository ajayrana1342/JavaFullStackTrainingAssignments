class Test2{
	int a=10;
	static int b=20;
	void add(){
	int c=a+b;
	System.out.println(c);
	}
	
	
	public static void main(String args[]){
	Test2 t= new Test2();
	t.add();
	t.a=20;
	t.b=30;
	System.out.println(t.a);
	System.out.println(b);
	
	Test2 s= new Test2();
	s.add();
	s.a=20;
	s.b=30;
	System.out.println(s.a);
	System.out.println(b);
	
	
	}
	
}