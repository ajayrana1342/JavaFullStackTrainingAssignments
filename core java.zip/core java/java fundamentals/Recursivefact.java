class RecursiveFact{
public static void main(String args[]){
    int a=Integer.parseInt(args[0]);
    int x=Rec(a);
	System.out.println(x);
}
static int Rec(int n){
   if(n==0) return 1;
   else{ return n*Rec(n-1);}

}}