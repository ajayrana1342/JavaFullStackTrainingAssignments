class CheckNo{
public static void main(String args[]){
    int a=Integer.parseInt(args[0]);
   if(a%2==0){System.out.println("EVEN NUMBER");}
   else{System.out.println("ODD NUMBER");}
   }   


}