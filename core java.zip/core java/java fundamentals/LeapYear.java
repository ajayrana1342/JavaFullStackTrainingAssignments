class LeapYear{
public static void main(String args[]){
    int a=Integer.parseInt(args[0]);
 
   if(a%4==0){
     if(a%100!=0){System.out.println("Leap year");}
      else{
	  if(a%400==0){System.out.println("Leap year");}}
   
   } 
   else {System.out.println("Not a leap year");}


}}