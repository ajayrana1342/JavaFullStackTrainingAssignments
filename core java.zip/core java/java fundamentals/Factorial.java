class Factorial{
public static void main(String args[]){
    int a=Integer.parseInt(args[0]);
   int x=1;
	for(int i=1;i<=a;i++){
	x=x*i;
	
	}
	System.out.println(x);
	}}