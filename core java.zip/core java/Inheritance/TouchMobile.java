abstract class Mobile
 {
   abstract void screen();
 }
 
class KeypadMobile extends Mobile
 {
   void screen()
    {
	  System.out.println("no touch screen");
	}
 }
 
class TouchMobile extends Mobile
 {
   void screen()
    {
	  System.out.println("touch screen ");
	}
	public static void main(String args[])
	{
       KeypadMobile c=new KeypadMobile();
        c.screen();
       TouchMobile b=new TouchMobile();
        b.screen();	
      
	}
 }