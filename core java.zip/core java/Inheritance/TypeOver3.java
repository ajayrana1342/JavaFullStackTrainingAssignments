class TypeOver3
 {
   void show(StringBuffer a)
    {
	  System.out.println("StringBuffer method");
	}
	
	void show(String s)
	 { 
	   System.out.println("String Method");
	 }
	 
	 public static void main(String args[])
	  {
	    TypeOver3 m=new TypeOver3();
		m.show("AJAY");
		m.show(new StringBuffer("Rana"));
	  }
 }