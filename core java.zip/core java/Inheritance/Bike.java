abstract class Vehicle
 {
   abstract void start();
 }
 
class Car extends Vehicle
 {
   void start()
    {
	  System.out.println(" Starts by key");
	}
 }
 
class Bike extends Vehicle
 {
   void start()
    {
	  System.out.println(" Starts with kick");
	}
	public static void main(String args[])
	{
       Car c=new Car();
        c.start();
        Bike b=new Bike();
        b.start();	
       // Vehicle v=new Vehicle();		error
	}
 }