class TypeOver
 {
   void show(int a)
    {
	  System.out.println("Hello");
	}
	
	void show(String s)
	 { 
	   System.out.println("World");
	 }
	 
	 public static void main(String args[])
	  {
	    TypeOver m=new TypeOver();
		m.show('J');
	  }
 }