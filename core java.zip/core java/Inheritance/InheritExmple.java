class Person
 {
   String name;
   String date;
   Person(String name,String date)
   {
	   this.name=name;
	   this.date=date;
   }
   void display()
   {
	   System.out.println(name+" "+date);
   }
 }
 
class Teacher extends Person
 {
    double salary;
	String subject;
	Teacher(String name,String date,double salary,String subject)
	{
		super(name,date);
		this.subject=subject;
		this.salary=salary;
		
	}
	
	void display1()
	{
		System.out.println(name+" "+date+" "+subject+" "+salary);
	}
 } 
 
class Student extends Person
 {
    int studentid;
	Student(String name,String date,int studentid)
	 {
		 super(name,date);
		 this.studentid=studentid;
	 }
	 
	 void display2()
	 {
		 System.out.println(name+" "+date+" "+studentid);
	 }
 }
 
class CollegeStudent extends Student
 {
   String year;
   String collegeName; 
   CollegeStudent(String name,String date,int studentid,String year,String collegeName)
   {
	   super(name,date,studentid);
	   this.year=year;
	   this.collegeName=collegeName;
   }
   
   void display3()
   {
	   System.out.println(name+" "+date+" "+studentid+" "+year+" "+collegeName);
   }
 }
 
public class InheritExmple
 {
	 public static void main(String args[])
	 {
		 Teacher t=new Teacher("AJAY","01/07/2002",10000,"JAVA");
		 t.display();
		 t.display1();
		 Student s=new Student("AJAY","01/07/2002",10);
		 s.display();
		 s.display2();
		 CollegeStudent c=new CollegeStudent("AJAY","01/07/2002",10,"Fourth","IET-DAVV");
		 c.display();
		 c.display3();
	 }
 }