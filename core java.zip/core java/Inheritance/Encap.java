class Author
  {
    private String name;
	private String email;
	private char gender;
   Author( String name,String email,char gender)
    {
	  this.name=name;
	  this.email=email;
	  this.gender=gender;
	
	}
	public void setName(String name){ this.name=name;}
	public void setEmail(String email){ this.email=email;}
	public void setGender(char gender){ this.gender=gender;}
	
	public String getName(){return name;}
	public String getEmail(){return email;}
	public char getGender(){return gender;}
	
	public String toString()
	{
		return "name="+name+"email="+email+"gender="+gender;
	}
	
	
  
  }
class Book
 {
   private String name;
   private Author A;
   private double Price;
   private int qtyInStock;
  
   Book(String name,Author A,double Price,int qtyInStock)
   { 
     this.name=name;
	 this.A=A;
	 this.Price=Price;
	 this.qtyInStock=qtyInStock;
   
   }
   public void setName(String name){ this.name=name;}
   public void setPrice(double Price){ this.Price=Price;}
   public void setQuantity(int qtyInStock){ this.qtyInStock=qtyInStock;}
    
	double getPrice()
	{
		return Price;
	}
	
	int getQuantity()
	{
		return qtyInStock;
	}
	String getName()
	{
		return name;
	}
	Author getAuthor()
	{return A;}
	
	public String toString()
	 {
		 return "name of book="+name+"author="+A+"price="+Price+"Quantity="+qtyInStock;
	 }
   
 
 }

class Encap
  {
    public static void main(String args[])
	{  Author a=new Author("AJAY","ajay@gmail.com",'m');
	  Book b=new Book("JAVA",a,100,15);
	  System.out.println(b);
	}
  }