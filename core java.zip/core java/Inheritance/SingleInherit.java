
class Test 
 {
   void show()
    {
	  System.out.println("Inherit");
	}
 
 }

class SingleInherit extends Test
 {
   public static void main(String args[])
   {
     SingleInherit t =new SingleInherit();
	 t.show();
   }
 }
 
 