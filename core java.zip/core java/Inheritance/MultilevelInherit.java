 class Test 
 {
   void show()
    {
	  System.out.println("1st class");
	}
 
 }
 class Test1 extends Test
  {
    void show1()
	{
	  System.out.println("2nd class");
	}
  }

class MultilevelInherit extends Test1
 {   void show2()
     {
	 System.out.println("3nd class");
	 }
 
   public static void main(String args[])
   {  Test t=new Test();
      t.show();
	  Test1 t1=new Test1();
	  t1.show();
	  t1.show1();
	  
	MultilevelInherit t2 =new MultilevelInherit();
	 t2.show();
	 t2.show1();
	 t2.show2();
   }
 }