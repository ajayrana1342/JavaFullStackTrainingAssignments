class A
 {
   Object show()
    {
	  System.out.println("Object method");
	  return null;
	}
}

class MethodOver1 extends A{
	String show()
	 { 
	   System.out.println("String method");
	   return null;
	 }
	 
	 public static void main(String args[])
	  {
         A a=new A();
		 MethodOver1 m=new MethodOver1();
	
		 a.show();
		 m.show();
		
	  }
 }