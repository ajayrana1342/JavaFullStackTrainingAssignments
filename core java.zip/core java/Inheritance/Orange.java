class Fruit
 {
   String name;
   String taste;
   String size;
   void eat(String name,String taste)
    {  
	  this.name=name;
	  this.taste=taste;
	  System.out.println(name+""+taste);
	}
 }
 
class Apple extends Fruit
  {
  void eat(String name,String taste)
   {
     System.out.println("Mango is tasty");
   }
  }
  
class Orange extends Fruit
 {
  void eat(String name,String taste)
  {
    System.out.println("Orange is sour");
  }
  
  public static void main(String args[])
   {
     Fruit f=new Fruit();
	 f.eat("Mango","sweet");
	 Apple a=new Apple();
	 a.eat("Mango","sweet");
	 Orange o=new Orange();
	 o.eat("Mango","sweet");
     
   }
 }