class A
 {
   void show(int a,String s)
    {
	  System.out.println("Hello");
	}
}

class MethodOver extends A{
	void show(int a,String s)
	 { 
	   System.out.println("World");
	 }
	 
	 public static void main(String args[])
	  {
         A a=new A();
		 MethodOver m=new MethodOver();
		 A a1=new MethodOver();
		// MethodOver  m1=new A();
		 a.show(10,"AJAY");
		 m.show(20,"RANA");
		 a1.show(30,"AJAY");
		// m1.show(40,"AJAY");
	  }
 }