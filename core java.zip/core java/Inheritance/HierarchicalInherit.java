class A
  {
    void show()
	{
	System.out.println("1st class");}
  }

class B extends A
 {
  void show1()
	{
	System.out.println("2st class");}
 }
 
class HierarchicalInherit extends A
 {
    void show2()
	{
	System.out.println("1st class");}
	
	public static void main(String args[])
	{
	  A t=new A();
	  B t1=new B();
	  HierarchicalInherit t2=new HierarchicalInherit();
	  t.show();
	  t1.show();
	  t1.show1();
	  t2.show();
	  t2.show2();
	
	}
  
 }