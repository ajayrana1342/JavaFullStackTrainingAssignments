class Employee
{   
    private int emp_id;
	private String name;
	public void setEmpId(int emp_id,String name)
	{
	   this.emp_id=emp_id;
	   this.name=name;
	}
	public int getEmpId()
	 { 
	   return emp_id;
	 }
	 public String gtEmpId()
	 {
		 return name;
	 }
	 
}
class Oraganization
 {
	 public static void main(String args[])
	  {
		  Employee e= new Employee();
		  e.setEmpId(1000,"AJAY");
		  System.out.println(e.getEmpId());
		   System.out.println(e.gtEmpId());
	  }
 }