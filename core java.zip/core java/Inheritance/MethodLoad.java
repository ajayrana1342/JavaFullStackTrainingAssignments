class MethodLoad 
 {
   void show(Long a,String s)
    {
	  System.out.println("Hello");
	}
	
	void show(int a,String s)
	 { 
	   System.out.println("World");
	 }
	 
	 public static void main(String args[])
	  {
	    MethodLoad m=new MethodLoad();
		m.show(10L,"A");
		m.show(10,"A");
	  }
 }