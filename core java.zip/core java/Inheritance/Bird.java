class Animal
 {
  void eat()
  {
   System.out.println("Eating");
  }
  void sleep()
  {
   System.out.println("Sleeping");
  }
 }
 
class Bird extends Animal
 {
  void fly()
  {
    System.out.println("Flying");
  }
  public static void main(String args[])
  {
     Animal A=new Animal();
     A.eat();
     A.sleep();
     Bird B=new Bird();
     B.eat();
     B.sleep();
     B.fly();	 
  }
 }