import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

class propertiesDemo
 {
	 public static void main(String args[])
	 {
		 Properties p=new Properties();
		 p.setProperty("Madhya Pradesh","Bhopal");
		 p.setProperty("Maharashtra","Mumbai");
		 p.setProperty("Gujarat","Gandhinagar");
		 p.setProperty("Rajasthan","jaipur");
		 Set<Map.Entry<Object,Object>> s=p.entrySet();
		 Iterator<Map.Entry<Object,Object>> itr=s.iterator();
		 while(itr.hasNext())
		 {
			 Map.Entry<Object,Object> e=itr.next();
			 System.out.println(e);
		 }
		 
	 }
 }