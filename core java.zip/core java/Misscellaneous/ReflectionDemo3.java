import java.lang.Class;
import java.lang.reflect.*;
class Animal
 {
	 
 }

  class Dog extends Animal
  {   int x[]={1,2,3,4,5};
      int p=10;
	  public void display()
	   {
		   System.out.println("I am a dog");
	   }
  }
  
  class ReflectionDemo3
   {
	   public static void main(String args[])
	    {
			try
			 {   
				 Dog d=new Dog();
				 Class c=d.getClass();
				  System.out.println(c.isArray());
				  System.out.println(c.isPrimitive());
				 String name=c.getName();
				 System.out.println("name:-"+name);
				 
			 }
			 catch(Exception e )
			 {
				 e.printStackTrace();
			 }
		}
   }