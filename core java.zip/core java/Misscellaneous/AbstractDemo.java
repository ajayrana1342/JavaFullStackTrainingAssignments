abstract class Generalbank
{
	abstract float getSavingsInterestRate(float f);
	abstract float getFixedDepositInterestRate(float d);
}
class Sbi extends Generalbank
{    
     float f,d;
	 float getSavingsInterestRate(float f)
	{    this.f=f;
		return f;
	}
	 float getFixedDepositInterestRate(float d)
	{   this.d=d;
		return d;
	}
}
class Icici extends Generalbank
{    
     float f,d;
	 float getSavingsInterestRate(float f)
	{    this.f=f;
		return f;
	}
	 float getFixedDepositInterestRate(float d)
	{   this.d=d;
		return d;
	}
}
class AbstractDemo
{
	public static void main(String args[])
	{
		Sbi s=new Sbi();
		System.out.println(s.getSavingsInterestRate(4f));
		System.out.println(s.getFixedDepositInterestRate(8.5f));
		Icici i=new Icici();
		System.out.println(i.getSavingsInterestRate(4f));
		System.out.println(i.getFixedDepositInterestRate(7f));
		Generalbank g=new Sbi();
		Generalbank g1=new Icici();
		System.out.println(g.getSavingsInterestRate(4f));
		System.out.println(g.getFixedDepositInterestRate(8.5f));
		System.out.println(g1.getSavingsInterestRate(4f));
		System.out.println(g1.getFixedDepositInterestRate(8.5f));
		
		
	}
}