class EnumSwitch
 { 
    enum Day{ SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THIRSDAY,FRIDAY,SATURDAY;}
     public static void main(String args[])
	  {
		  Day d=Day.MONDAY;
		  System.out.println(d);
		  for(Day t:Day.values())
		  {
			  System.out.println(t);
		  }
		  System.out.println("value of thirsday:-"+Day.valueOf("THIRSDAY"));
		  System.out.println("Index of Tuesday is "+Day.valueOf("TUESDAY").ordinal());
		  
		  
		  switch(d)
		   {    case MONDAY:
			   {
				   System.out.println("Monday");
				   break;
			   }
			   case SUNDAY:
			   {
				   System.out.println("Sunday");
				   break;
			   }
			   case TUESDAY:
			   {
				   System.out.println("tuesday");
				   break;
			   }
			   case WEDNESDAY:
			   {
				   System.out.println("wednesday");
				   break;
			   }
			   case THIRSDAY:
			   {
				   System.out.println("thirsday");
				   break;
			   }
			   case FRIDAY:
			   {
				   System.out.println("friday");
				   break;
			   }
			   case SATURDAY:
			   {
				   System.out.println("Saturday");
				   break;
			   }
			   default:
			   {
				   System.out.println("Choose other day");
			   }
		   }
	  }
 }