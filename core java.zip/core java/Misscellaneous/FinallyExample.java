 class FinallyExample
 {
	 public static void main(String args[])
	 {
	   int a=10;
       int b=0;
	   try
	   {
       int c=a/b;
       System.out.println(c);	
	   }
        catch(ArithmeticException e)
		{
			e.printStackTrace();
		}	  
          finally
		  {
			  System.out.println("I am in finally block");
		  }		
	 }
 }