import java.io.Console;
class ConsoleDemo
 {   
   
	 public static void main(String args[])
	 {
		 String str;
		 char ch[];
		 Console ob=System.console();
		 System.out.println("Enter Username :-");
		 str=ob.readLine();
		 System.out.println("Enter Password :-");
		 ch=ob.readPassword();
		 System.out.println("Username:-"+str+"Password:-"+ch);
		 String a=String.valueOf(ch);
		 System.out.println("Actual Password"+a);
	 }
 }