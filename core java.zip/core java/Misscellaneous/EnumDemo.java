class EnumDemo
 { enum Season{WINTER(2),SPRING(4),SUMMER(6),FALL(8);
  int value;
  Season(int value)
   {
	   this.value=value;
   }
 }
 
	 public static void main(String args[])
	  {
		  for(Season x:Season.values())
		  {
			  System.out.println(x+" "+x.value);
		  }
		  System.out.println("value of spring:-"+Season.valueOf("SPRING"));
		  System.out.println("Index of SPRING is "+Season.valueOf("SPRING").ordinal());
	  }
 } 
