import javax.swing.*;
public class JoptionDemo
{
	JFrame f;
	JoptionDemo()
	{
		f=new JFrame();
		JOptionPane.showMessageDialog(f,"AJAY RANA");
		String name=JOptionPane.showInputDialog(f,"Enter name");
		JOptionPane.showMessageDialog(f,"SUCCESS","TEXT",JOptionPane.WARNING_MESSAGE);
		
	}
	public static void main(String args[])
	{
		new JoptionDemo();
		System.exit(0);
	}
}