import java.io.FileInputStream;
import java.io.IOException;
class CheckedExcepDemo
 {
	 public static void main(String args[])
	 {
	    try
		 {
			 FileInputStream f=new FileInputStream("d:/ajay");
			 f.read();
			 f.close();
			 
		 }
		 catch(IOException e)
		 {
			 e.printStackTrace();
		 }
		 try
		 {
			 Class temp=Class.forName("ajay");
		 }
		 catch(ClassNotFoundException e)
		  {
			  e.printStackTrace();
		  }
	  
	  
	  
	   
	 }
 }