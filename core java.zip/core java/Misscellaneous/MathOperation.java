import java.util.Scanner;
class MathOperation
 {
	 public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 int s=5;
		 int a[]=new int[s];
		  try
		 {
		 int sum=0;
		 for(int i=0;i<s;i++)
		 {
		  a[i]=Integer.parseInt(sc.next());
		  sum=sum+a[i];
		  
		 }
		 int average=sum/5;
		
		 System.out.println(sum+""+average);
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
			 
		 }
	 }
 }