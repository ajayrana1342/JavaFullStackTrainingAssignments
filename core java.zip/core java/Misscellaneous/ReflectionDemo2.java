import java.lang.Class;
import java.lang.reflect.*;
class Animal
 {
	 
 }
  class Dog extends Animal
  {
	  public void display()
	   {
		   System.out.println("I am a dog");
	   }
  }
  
  class ReflectionDemo2
   {
	   public static void main(String args[])
	    {
			try
			 {
				 Class c=Dog.class;
				 String name=c.getName();
				 System.out.println("name:-"+name);
				 
			 }
			 catch(Exception e )
			 {
				 e.printStackTrace();
			 }
		}
   }