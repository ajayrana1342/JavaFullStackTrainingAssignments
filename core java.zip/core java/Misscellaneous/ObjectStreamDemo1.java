import java.io.*;
import java.util.Scanner;
class Employee implements Serializable
 {
  private String name;
  private String department;
  private String designation;
   private double salary;
   Employee()
    {
		System.out.println("Serializable");
	}
   Employee(String name,String department,String designation,double salary)
    {    this.name=name;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
	}
  void setName(String name){
	   this.name=name;
   }
   void setDepartment(String department){
	   this.department=department;
   }
   void setDesignation(String designation){
	   this.designation=designation;
   }
   void setSalary(double salary){
	   this.salary=salary;
   }
   String getName(){return name;}
   String getDepartment(){return department;}
   String getDesignation(){return designation;}
   double getSalary(){return salary;}
    public String toString()
		 {
			 return name+" "+department+" "+designation+" "+salary;
		 }
 }
 
class ObjectStreamDemo1
 {
	 public static void main(String args[]) throws Exception
	 {   Scanner sc=new Scanner(System.in);
	     String p=sc.next();
		 String q=sc.next();
		 String r=sc.next();
		 double s=sc.nextDouble();
		  Employee e1=new Employee();
		 Employee e=new Employee(p,q,r,s);
		e1.setName("AJAY");
		 e1.setDepartment("Development");
		 e1.setDesignation("Software Developer");
		 e1.setSalary(500000);
		 e1.getName();
		 e1.getDepartment();
		 e1.getDesignation();
		 e1.getSalary();
		 File f=new File("d:/yash/xyz.txt");
		 ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		 oos.writeObject(e);
		 oos.writeObject(e1);
		 oos.close();
		 
		 ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		 Employee x=(Employee)ois.readObject();
		 System.out.println(x);
		 Employee x1=(Employee)ois.readObject();
		 ois.close();
		 System.out.println(x1);
		 
		
		 
		 
		 
	 }
 }