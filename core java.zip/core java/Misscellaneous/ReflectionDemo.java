import java.lang.Class;
import java.lang.reflect.*;
class Animal
 {
	 
 }
 interface b{}
  class Dog extends Animal
  {
	  public void display()
	   {
		   System.out.println("I am a dog");
	   }
  }
  
  class ReflectionDemo
   {
	   public static void main(String args[])
	    {
			try
			 {   
				 Dog d=new Dog();
				 Class c=d.getClass();
				  System.out.println(c.isInterface());
				 String name=c.getName();
				 System.out.println("name:-"+name);
				 
			 }
			 catch(Exception e )
			 {
				 e.printStackTrace();
			 }
		}
   }