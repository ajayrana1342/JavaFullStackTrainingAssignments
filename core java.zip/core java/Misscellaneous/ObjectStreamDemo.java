import java.io.*;
class Employee implements Serializable
 {
  private String name;
  private String department;
  private String designation;
   private double salary;
   void setName(String name){
	   this.name=name;
   }
   void setDepartment(String department){
	   this.department=department;
   }
   void setDesignation(String designation){
	   this.designation=designation;
   }
   void setSalary(double salary){
	   this.salary=salary;
   }
   String getName(){return name;}
   String getDepartment(){return department;}
   String getDesignation(){return designation;}
   double getSalary(){return salary;}
    public String toString()
		 {
			 return name+" "+department+" "+designation+" "+salary;
		 }
 }
 
class ObjectStreamDemo
 {
	 public static void main(String args[]) throws Exception
	 {
		 Employee e=new Employee();
		 e.setName("AJAY");
		 e.setDepartment("Development");
		 e.setDesignation("Software Developer");
		 e.setSalary(500000);
		 e.getName();
		 e.getDepartment();
		 e.getDesignation();
		 e.getSalary();
		 File f=new File("d:/yash/abc.txt");
		 ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		 oos.writeObject(e);
		 oos.close();
		 
		 ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		 Employee x=(Employee)ois.readObject();
		 ois.close();
		 System.out.println(x);
		 
		
		 
		 
		 
	 }
 }