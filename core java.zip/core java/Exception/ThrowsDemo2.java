import java.io.*;
class ThrowsDemo2
 {
	 public static void main(String args[]) throws ClassNotFoundException
	 {
		 
		 try{
		 Class t =Class.forName("yash");
		 }
		 catch(ClassNotFoundException e)
		 {
			 e.printStackTrace();
		 }
		 System.out.println("normal termination");
	 }
 }