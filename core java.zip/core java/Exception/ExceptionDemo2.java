class ExceptionDemo2
{
	public static void main(String args[])
	{
		try
		{  System.out.println("First try");
		    String s=null;
		   System.out.println(s.length());
		}
		catch(Exception e)
		 {
			 System.out.println(e);
		 }
		System.out.println("Exception free");
		try
		{
		 System.out.println("Another try");	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}