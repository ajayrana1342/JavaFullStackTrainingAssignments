import java.io.FileInputStream;
class ExceptionChecked
 {
	 public static void main(String args[])
	 {
		 FileInputStream f=new FileInputStream("D:/xyz.txt");
	 }
 }