import java.util.Scanner;
class NumberException
 {
	 public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 String s=sc.next();
		 try
		 {
		 int n=Integer.parseInt(s);
		 System.out.println(n*n);
		 }
		 catch(NumberFormatException e)
		 {
			 System.out.println(e);
			 System.out.println("entered input is not a valid format");
		 }
	 }
 }