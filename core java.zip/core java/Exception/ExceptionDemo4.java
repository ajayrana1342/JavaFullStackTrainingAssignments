import java.util.Scanner;
class ExceptionDemo4
 {
	 public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 int s=sc.nextInt();
		 int a[]=new int[s];
		  try
		 {
		 for(int i=0;i<s;i++)
		 {
		  a[i]=Integer.parseInt(sc.next());
		 }
		
		 
		 int ind=sc.nextInt();
		 System.out.println(a[ind]);
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
			 System.out.println("entered valid number");
		 }
	 }
 }