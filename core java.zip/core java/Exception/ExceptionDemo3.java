import java.util.Scanner;
class ExceptionDemo3
 {
	 public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 int s=sc.nextInt();
		 int a[]=new int[s];
		 for(int i=0;i<s;i++)
		 {
		  a[i]=sc.nextInt();
		 }
		 try
		 {
		 
		 int ind=sc.nextInt();
		 System.out.println(a[ind]);
		 }
		 catch(ArrayIndexOutOfBoundsException e)
		 {
			 e.printStackTrace();
			 System.out.println("entered valid number");
		 }
	 }
 }