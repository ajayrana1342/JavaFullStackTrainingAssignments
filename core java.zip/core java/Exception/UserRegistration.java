import java.util.Scanner;
class InvalidCountryException  extends Exception
{  InvalidCountryException(String s){
super(s);}
}

class UserRegistration
 {   
    private String name;
	private String country; 
	 public void user(String name,String country)
	 {
		 this.name=name;
		 this.country=country;
		 System.out.println(name+" "+country);
	 }
	 
	 
	 
	 
}
class Country
{
	public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 
		 String s=sc.next();
		 String p=sc.next();
		 UserRegistration u=new UserRegistration();
		 try{
		 if(!p.equalsIgnoreCase("India"))
		 {
			 throw new InvalidCountryException("User outside India cannot registere");
		 }
		 else
		 {
			 
		 u.user(s,p);
		 System.out.println("registration done successfully");
		 }}
		 catch(InvalidCountryException e)
		 {
			 e.printStackTrace();
		 }
		 
	 }
	
}
