import java.util.Scanner;
class ValueException extends RuntimeException
{
   ValueException(String s)
   {
    super(s);
   }
 }
 
 class ThrowDemo2
 {
   public static void main(String args[])
   {
    Scanner sc=new Scanner(System.in);
	System.out.println("Enter your name");
	int a[]=new int[3];
	int b[]=new int[3];
	
	
	String s=sc.next();
	try{
	for(int i=0;i<3;i++)
	{
		a[i]=Integer.parseInt(sc.next());
	}
	System.out.println("Enter your name");
	String t=sc.next();
	
	for(int i=0;i<3;i++)
	{
		b[i]=Integer.parseInt(sc.next());
	}
	}
	catch(Exception e){
		e.printStackTrace();
	}
	int sum=0;
	int avg=0;
	try
	{
	for(int i=0;i<3;i++)
	{
		if((a[i]<0) || (a[i]>100) || (b[i]<0) || (b[i]>100) )
		{
			throw new ValueException("Enter number less than 100 or Greater than zero");
		}
		else
		{
			sum=sum+a[i]+b[i];
			
		}
	}
	avg=sum/2;
	System.out.println(avg);
	}
	catch(ValueException e)
	{
		e.printStackTrace();
	}
	
	
	
	
   }
 
 }