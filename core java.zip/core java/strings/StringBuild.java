import java.util.*;
class StringBuild
{
 public static void main(String arg[])
 {
   Scanner sc=new Scanner(System.in);
   StringBuilder s= new StringBuilder("");
   s.append(sc.nextLine());
      System.out.println(s.append("Rana")); 
 
 
 }
}