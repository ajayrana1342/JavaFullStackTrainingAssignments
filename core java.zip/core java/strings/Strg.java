class Strg
{
	public static void main(String args[])
	{
		String s=new String("My name is Ajay   ");
		String s1="";
		String s2="Ajay";
		String s3="ajay";
		System.out.println(s.isEmpty());
		System.out.println(s1.isEmpty());
		
		System.out.println(s.trim());
		System.out.println(s.equals(s1));
		System.out.println(s2.equals(s3));
		System.out.println(s2.equalsIgnoreCase(s3));
		System.out.println(s2.compareTo(s3));
		System.out.println(s2.compareToIgnoreCase(s3));
		System.out.println(s.substring(0,6));
		
	} 
}