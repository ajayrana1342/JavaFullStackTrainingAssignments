import java.util.Scanner;
class DeleteStrg
{
	public static void main(String args[])
	{
		Scanner sc =new Scanner(System.in);
		String s=sc.nextLine();
		int n=s.length();
		String x="";
		for(int i=1;i<n-1;i++)
		{
			x=x+s.charAt(i);
		}
		System.out.println(x);
	} 
}