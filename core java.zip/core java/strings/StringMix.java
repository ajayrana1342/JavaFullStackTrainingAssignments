import java.util.Scanner;
class StringMix
{
	public static void main(String args[])
	{
		Scanner sc =new Scanner(System.in);
		String x=sc.nextLine();
		String y=sc.nextLine();
		String z="";
		int a=x.length();
		int b=y.length();
		int p=0;
		int q=0;
		if(a<=b)
		{
		 for(int i=0;i<2*a;i++)
		 {
		  if(i%2==0)
		  {
		  z=z+x.charAt(p);p++;
		  }
		  else
		  {
		  z=z+y.charAt(q);q++;
		  }
		 }
		 for(int j=q;j<b;j++)
		 {
		 z=z+y.charAt(q);q++;
		 }
		}
		else
		{
		 for(int i=0;i<2*b;i++)
		 {
		  if(i%2==0)
		  {
		  z=z+x.charAt(p);p++;
		  }
		  else
		  {
		  z=z+y.charAt(q);q++;
		  }
		 }
		 for(int j=p;j<a;j++)
		 {
		 z=z+x.charAt(p);p++;
		 }
		}
	    System.out.println(z);
	
	} 
}