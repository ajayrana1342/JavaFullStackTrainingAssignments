class A
 {
	A()
	{
	  System.out.println("Class A constructor");	
	}
 }
 
class SuperDemo3 extends A
 {
     
	 SuperDemo3()
	 {
		 System.out.println("Class superdemo3 constructor");
		 
	 }
	 public static void main(String args[])
	 {
		 SuperDemo3 sd=new SuperDemo3();
		 
	 }
 }