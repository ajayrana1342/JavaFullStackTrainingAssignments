class A
 {
	 int a=100;
 }
 
class SuperDemo extends A
 {
	 int a=200;
	 void display(int a)
	 {
		 System.out.println(a);
		 System.out.println(this.a);
		 System.out.println(super.a);
	 }
	 public static void main(String args[])
	 {
		 SuperDemo sd=new SuperDemo();
		 sd.display(300);
	 }
 }