class A
 {
	void display()
	{
	  System.out.println("Class A");	
	}
 }
 
class SuperDemo2 extends A
 {
     
	 void display()
	 {
		 System.out.println("Class superdemo2");
		 
	 }
	 void show()
	 {
		 display();
		 super.display();
	 }
	 public static void main(String args[])
	 {
		 SuperDemo2 sd=new SuperDemo2();
		 sd.show();
	 }
 }