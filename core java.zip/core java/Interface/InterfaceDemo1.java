interface A
 {
	 public abstract void show();
	 public static final int a=20;
 }
interface B
 {
    void display();
 }
 
class InterfaceDemo1 implements A
 {
	 public void show()
	 {
		 System.out.println("In demo class");
	 }
	 public void display()
	 {
		 System.out.println("In display method");
	 }
	 public static void main(String args[])
	 {
		 InterfaceDemo1 d=new InterfaceDemo1();
		 d.show();
	 }
 }