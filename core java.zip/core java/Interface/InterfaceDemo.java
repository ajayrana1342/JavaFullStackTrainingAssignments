interface A1
 {
	 public abstract void show();
	 public static final int a=20;
 }
 
class InterfaceDemo implements A1
 {
	 public void show()
	 {
		 System.out.println("In demo class");
	 }
	 public static void main(String args[])
	 {
		 InterfaceDemo d=new InterfaceDemo();
		 d.show();
	 }
 }