interface Person
 {
	 public abstract void display();
	 default void add()
	 {
		System.out.println("AJAY"); 
	 }
	 
 }
interface Teacher
 {
    void display1();
 }
 
class InterfaceDemo2 implements Person,Teacher
 {    private void add()
      {
		  System.out.println("AJAY"); 
	  }
	 public void display()
	 {
		 System.out.println("I am a Person");
	 }
	 public void display1()
	 {
		 System.out.println("who teaches students");
	 }
	 public static void main(String args[])
	 {
		 InterfaceDemo2 d=new InterfaceDemo2();
		 d.display();
		 d.display1();
		 d.add();
	 }
 }