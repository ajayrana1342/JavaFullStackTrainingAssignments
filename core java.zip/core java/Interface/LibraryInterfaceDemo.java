import java.util.Scanner;
interface LibraryUser
{
    void registerAccount();
	void requestBook();
}
class KidUsers implements LibraryUser
{
	int age;String booktype;
	KidUsers(int age,String booktype)
	{
		this.age=age;
		this.booktype=booktype;
	}
	public  void registerAccount()
	{
		if(age<12){System.out.println("You have successfully registered under kids account");}
		else{System.out.println("Sorry age must be less than 12 for register as a kid");}
	}
	public void requestBook()
	{
       if(booktype.equalsIgnoreCase("kids"))
	   {
		   System.out.println("Book issues successfully,please return the book within 10 days");
	   }	
        else
		{
			System.out.println("Oops,you are allowed to only take kids book");
		}	   
	}
}

class AdultUsers implements LibraryUser
{
	int age;String booktype;
	AdultUsers(int age,String booktype)
	{
		this.age=age;
		this.booktype=booktype;
	}
	public void registerAccount()
	{
		if(age>=12){System.out.println("You have successfully registered under adult account");}
		else{System.out.println("Sorry age must be greater than 12 for register as a kid");}
	}
	public void requestBook()
	{
       if(booktype.equalsIgnoreCase("FICTION"))
	   {
		   System.out.println("Book issues successfully,please return the book within 7 days");
	   }	
        else
		{
			System.out.println("Oops,you are allowed to only take fiction book");
		}	   
	}
}

class LibraryInterfaceDemo
{
	public static void main(String args[])
	{   
	   Scanner sc=new Scanner(System.in);
	   int ag=sc.nextInt();
	   String s=sc.next();
	   KidUsers k=new KidUsers(ag,s);
	   AdultUsers a=new AdultUsers(ag,s);
	   k.registerAccount();
	   k.requestBook();
	   a.registerAccount();
	   a.requestBook();
	}
}