interface Person
 {
	 public abstract void display();
	 
 }
class Female
 {   void show(){
 System.out.println("Hello");}
 }
interface Teacher implements Female
 {
    void display1();
 }
 

 
class InterfaceDemo2 implements Person,Teacher
 {
	 public void display()
	 {
		 System.out.println("I am a Person");
	 }
	 public void display1()
	 {
		 System.out.println("who teaches students");
	 }
	 public static void main(String args[])
	 {
		 InterfaceDemo2 d=new InterfaceDemo2();
		 d.display();
		 d.display1();
	 }
 }